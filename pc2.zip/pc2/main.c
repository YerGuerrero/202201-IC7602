#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*calcularHamming(bits){

}*/
#define MAX 10000

int num_bits = sizeof(int)*8;

int main (int argc, char const *argv[]){
    unsigned int hexa ;
    scanf("%X",&hexa);
    printf("Hexadecimal: 0x%X\n", hexa);


    unsigned bitmask = 1 << (num_bits - 1);
    int bytes[sizeof(int)*8]= {0};
    //memset(bytes, 0, num_bits);
    int i = 0;

    for(i = 0; i != num_bits; i ++)
    {
        if(hexa & (bitmask >> i))
        {
            bytes[i]=1;
            printf("1");
        }
        else
        {
            bytes[i]=0;
            printf("0");
        }
    }

    printf("\nlista de bytes:");
    for (int j = 0; j < sizeof(bytes); ++j) {
        printf(" %i",bytes[j]);
    }


}

